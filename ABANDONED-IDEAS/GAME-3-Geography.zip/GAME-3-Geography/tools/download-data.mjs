// Downloads the Natural Earth source data (public domain) into tools/raw.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const RAW = path.join(path.dirname(fileURLToPath(import.meta.url)), 'raw');
fs.mkdirSync(RAW, { recursive: true });
const GH = 'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/';
const files = ['ne_10m_admin_0_map_units', 'ne_10m_admin_0_countries_ind', 'ne_50m_populated_places'].map(f => [GH + f + '.geojson', f + '.geojson']);
files.push(['https://naciscdn.org/naturalearth/50m/raster/SR_50M.zip', 'SR_50M.zip']);
for (const [url, name] of files) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${url}: ${r.status}`);
  fs.writeFileSync(path.join(RAW, name), Buffer.from(await r.arrayBuffer()));
  console.log('downloaded', name);
}
console.log('Now unzip raw/SR_50M.zip into raw/SR_50M, then run: npm run build');
