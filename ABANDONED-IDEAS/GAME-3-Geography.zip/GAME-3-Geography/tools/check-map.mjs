// Drives WORLD-MAP.html in Chrome: runs the built-in checks, times every sheet, and tries taps,
// search and a phone-sized screen. Usage: node check-map.mjs [screenshot folder]
import puppeteer from 'puppeteer-core';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const url = pathToFileURL(path.join(here, '..', 'WORLD-MAP.html')).href;
const shots = process.argv[2];
const chrome = ['C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'];
const browser = await puppeteer.launch({ executablePath: chrome[0], headless: true });
const errors = [];
const page = await browser.newPage();
page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });

// 1. built-in checks
await page.goto(url + '?check');
await page.waitForSelector('#checkOut', { timeout: 120000 });
const report = JSON.parse(await page.$eval('#checkOut', e => e.textContent));
console.log('checks:', report.problems.length ? report.problems : 'all passed', `(${report.countries} countries)`);

// 2. time each sheet, then tap tests on a desktop screen
await page.setViewport({ width: 1280, height: 900 });
await page.goto(url + '#world');
await page.waitForFunction(() => document.getElementById('busy').hidden, { timeout: 60000 });
const times = await page.evaluate(async () => {
  const t = {};
  for (const s of GEO_SHEETS) { const a = performance.now(); await new Promise(r => window.__open(s.id, r)); t[s.id] = Math.round(performance.now() - a); }
  return t;
}).catch(e => ({ error: e.message }));
console.log('sheet build ms:', JSON.stringify(times));

const tapAt = async (lon, lat) => {
  const p = await page.evaluate((lon, lat) => window.__screenPoint(lon, lat), lon, lat);
  await page.mouse.click(p[0], p[1]);
  await new Promise(r => setTimeout(r, 150));
  return page.evaluate(() => document.getElementById('card').hidden ? null : document.getElementById('cName').textContent);
};
const open = id => page.evaluate(id => new Promise(r => window.__open(id, r)), id);
await open('sam');
console.log('tap Brazil  ->', await tapAt(-50, -10));
console.log('tap Bolivia ->', await tapAt(-64.5, -17));
await open('eus');
console.log('tap Vatican ->', await tapAt(12.4533, 41.9029));
console.log('tap San Marino ->', await tapAt(12.457, 43.94));
await open('world');
console.log('tap India on world ->', await tapAt(79, 22));
console.log('tap Kashmir (Gilgit) ->', await tapAt(74.5, 36));
console.log('tap Aksai Chin ->', await tapAt(79.5, 35.2));
console.log('tap Crimea ->', await tapAt(34.2, 45.2));
console.log('tap Fiji (date line) ->', await tapAt(178.1, -17.8));
// search
await page.click('#search', { clickCount: 3 });
await page.type('#search', 'tuvalu');
await page.keyboard.press('Enter');
await new Promise(r => setTimeout(r, 1500));
console.log('search tuvalu ->', await page.evaluate(() => [location.hash, document.getElementById('cName').textContent]));
if (shots) await page.screenshot({ path: path.join(shots, 'desk-search.png') });

// 3. phone, portrait
await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 3, isMobile: true, hasTouch: true });
await page.goto(url + '#sam');
await page.waitForFunction(() => document.getElementById('busy').hidden, { timeout: 60000 });
const p = await page.evaluate(() => window.__screenPoint(-50, -10));
await page.touchscreen.tap(p[0], p[1]);
await new Promise(r => setTimeout(r, 300));
console.log('phone tap Brazil ->', await page.evaluate(() => document.getElementById('cName').textContent));
if (shots) await page.screenshot({ path: path.join(shots, 'phone.png') });
await page.setViewport({ width: 844, height: 390, deviceScaleFactor: 3, isMobile: true, hasTouch: true });
await new Promise(r => setTimeout(r, 400));
if (shots) await page.screenshot({ path: path.join(shots, 'phone-land.png') });

console.log('page errors:', errors.length ? errors : 'none');
await browser.close();
