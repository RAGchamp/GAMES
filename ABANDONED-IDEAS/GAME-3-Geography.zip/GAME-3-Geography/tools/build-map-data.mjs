// Build data/world-shapes.js for the Geography world map.
//
// Sources (public domain, Natural Earth, downloaded into tools/raw by `npm run download`):
//   ne_10m_admin_0_map_units.geojson     standard borders, overseas parts split out
//   ne_10m_admin_0_countries_ind.geojson India's official point of view
//   ne_50m_populated_places.geojson      capitals
//
// Run from GAME-3-Geography/tools:  node build-map-data.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mapshaper from 'mapshaper';
import * as topojson from 'topojson-client';
import polylabel from 'polylabel';

const TOOLS = path.dirname(fileURLToPath(import.meta.url));
const RAW = path.join(TOOLS, 'raw');
const OUT = path.join(TOOLS, '..', 'data', 'world-shapes.js');
const readJSON = f => JSON.parse(fs.readFileSync(path.join(RAW, f), 'utf8'));

// ---------- country lists ----------
// The 193 UN members plus the two observer states (Vatican City, Palestine), as Natural Earth codes.
const UN195 = new Set(`
DZA AGO BEN BWA BFA BDI CPV CMR CAF TCD COM COG COD CIV DJI EGY GNQ ERI SWZ ETH GAB GMB GHA GIN GNB KEN LSO LBR LBY MDG
MWI MLI MRT MUS MAR MOZ NAM NER NGA RWA STP SEN SYC SLE SOM ZAF SDS SDN TZA TGO TUN UGA ZMB ZWE
AFG ARM AZE BHR BGD BTN BRN KHM CHN CYP GEO IND IDN IRN IRQ ISR JPN JOR KAZ KWT KGZ LAO LBN MYS MDV MNG MMR NPL PRK OMN
PAK PHL QAT KOR SAU SGP LKA SYR TJK THA TLS TUR TKM ARE UZB VNM YEM
ALB AND AUT BLR BEL BIH BGR HRV CZE DNK EST FIN FRA DEU GRC HUN ISL IRL ITA LVA LIE LTU LUX MLT MDA MCO MNE NLD MKD NOR
POL PRT ROU RUS SMR SRB SVK SVN ESP SWE CHE UKR GBR
ATG ARG BHS BRB BLZ BOL BRA CAN CHL COL CRI CUB DMA DOM ECU SLV GRD GTM GUY HTI HND JAM MEX NIC PAN PRY PER KNA LCA VCT
SUR TTO USA URY VEN
AUS FJI KIR MHL FSM NRU NZL PLW PNG WSM SLB TON TUV VUT
VAT PSX`.trim().split(/\s+/));

// Drawn as land but never labelled or quizzed (reefs, bases, buffer zones, uninhabited lands).
const UNLABELLED = new Set('ATA BRT BRI SPI CNM SER BJN SCR PGA USG ESB WSB UMI HMD ATF IOA CSI ATC CLP IOT SGS'.split(' '));

// Overseas parts of France shown as their own map units (French Guiana is on the reference picture).
const SPLIT_UNITS = new Set(['GUF', 'MTQ', 'GLP', 'REU', 'MYT']);

// Countries whose shape is taken from India's official point of view (agreed 22 Nov 2026).
// Cyprus and Morocco are left out so that Northern Cyprus and Western Sahara stay visible.
const FROM_INDIA_VIEW = new Set(['IND', 'PAK', 'CHN', 'UKR', 'RUS', 'ISR', 'LBN', 'SDN', 'BRA', 'COL', 'GRL', 'KAZ']);
const DROP = new Set(['KAS', 'KAB']); // Siachen and Baikonur: covered by India and Kazakhstan in the India view

// Short, familiar English names (agreed 22 Nov 2026).
const SHORT = {
  CHN: 'China', USA: 'United States', COD: 'DR Congo', COG: 'Congo', CZE: 'Czechia', FSM: 'Micronesia',
  BHS: 'Bahamas', GMB: 'Gambia', TLS: 'East Timor', SWZ: 'Eswatini', BIH: 'Bosnia & Herzegovina',
  VCT: 'St Vincent & Grenadines', KNA: 'St Kitts & Nevis', LCA: 'St Lucia', ATG: 'Antigua & Barbuda',
  TTO: 'Trinidad & Tobago', STP: 'São Tomé & Príncipe', CAF: 'Central African Rep.', DOM: 'Dominican Rep.',
  MAC: 'Macao', PSX: 'Palestine', SAH: 'Western Sahara', CYN: 'Northern Cyprus', SOL: 'Somaliland',
  TCA: 'Turks & Caicos', VIR: 'US Virgin Islands', VGB: 'British Virgin Is.', MNP: 'Northern Mariana Is.',
  SPM: 'St Pierre & Miquelon', WLF: 'Wallis & Futuna', HKG: 'Hong Kong', KOS: 'Kosovo', CIV: 'Ivory Coast',
  ALD: 'Åland', MAF: 'Saint Martin', BLM: 'St Barthélemy', ARE: 'UAE', GNQ: 'Equatorial Guinea',
};

// Capitals for places the Natural Earth capital points do not cover.
const CAPITAL_FIX = {
  DNK: 'Copenhagen', KAZ: 'Astana', USA: 'Washington, D.C.', BEN: 'Porto-Novo', COL: 'Bogotá', YEM: "Sana'a",
  ABW: 'Oranjestad', CUW: 'Willemstad', SXM: 'Philipsburg', PYF: 'Papeete', GUM: 'Hagåtña', BMU: 'Hamilton',
  FRO: 'Tórshavn', GIB: 'Gibraltar', IMN: 'Douglas', JEY: 'Saint Helier', GGY: 'Saint Peter Port',
  CYM: 'George Town', ALD: 'Mariehamn', ASM: 'Pago Pago', AIA: 'The Valley', VGB: 'Road Town', COK: 'Avarua',
  MSR: 'Brades (temporary)', NIU: 'Alofi', NFK: 'Kingston', MNP: 'Saipan', PCN: 'Adamstown', SHN: 'Jamestown',
  MAF: 'Marigot', BLM: 'Gustavia', SPM: 'Saint-Pierre', TCA: 'Cockburn Town', VIR: 'Charlotte Amalie', WLF: 'Mata-Utu',
  GUF: 'Cayenne', MTQ: 'Fort-de-France', GLP: 'Basse-Terre', REU: 'Saint-Denis', MYT: 'Mamoudzou',
  PSX: 'Ramallah (seat of government)', ISR: 'Jerusalem (disputed)', BOL: 'Sucre (constitutional), La Paz (seat of government)',
  ZAF: 'Pretoria, Cape Town and Bloemfontein', NLD: 'Amsterdam', CIV: 'Yamoussoukro', LKA: 'Sri Jayawardenepura Kotte',
  SAH: 'Laayoune (claimed)', CYN: 'North Nicosia', SOL: 'Hargeisa', KOS: 'Pristina', TWN: 'Taipei',
  MMR: 'Naypyidaw', NRU: 'Yaren (no official capital)', KIR: 'Tarawa', PLW: 'Ngerulmud', FSM: 'Palikir',
  MHL: 'Majuro', TUV: 'Funafuti', MDV: 'Malé', CHE: 'Bern', MYS: 'Kuala Lumpur', BDI: 'Gitega', EGY: 'Cairo',
  IDN: 'Jakarta', GRL: 'Nuuk', HKG: 'Hong Kong', MAC: 'Macao', FLK: 'Stanley', PRI: 'San Juan', NCL: 'Nouméa',
  ATA: '', VAT: 'Vatican City', MCO: 'Monaco', SGP: 'Singapore', TZA: 'Dodoma', SDS: 'Juba',
};

// Notes shown on the country card where a border or status is disputed.
const NOTES = {
  IND: "Borders follow India's official view: all of Jammu and Kashmir, including Ladakh and Aksai Chin, is shown as part of India.",
  PAK: "Shown without Pakistan-administered Kashmir, following India's official view.",
  CHN: "Aksai Chin is shown as part of India, following India's official view.",
  UKR: "Crimea is shown as part of Ukraine, following India's official view.",
  RUS: "Crimea is shown as part of Ukraine, following India's official view.",
  KOS: 'Kosovo declared independence in 2008. Many countries recognise it, but not all.',
  SAH: 'The status of Western Sahara is disputed. Most of it is administered by Morocco.',
  TWN: 'Taiwan is governed separately from mainland China. Its status is disputed.',
  PSX: 'Palestine is a UN observer state.',
  VAT: 'Vatican City is a UN observer state and the smallest country in the world.',
  CYN: 'Northern Cyprus is recognised only by Turkey.',
  SOL: 'Somaliland declared independence from Somalia in 1991 but is not internationally recognised.',
  FLK: 'Governed by the United Kingdom and claimed by Argentina.',
};

// ---------- which map sheet each place belongs to ----------
const SUB_TO_SHEET = {
  'South America': 'sam', 'Northern America': 'nam', 'Central America': 'cam', 'Caribbean': 'car',
  'Northern Europe': 'eun', 'Western Europe': 'euw', 'Eastern Europe': 'eue', 'Southern Europe': 'eus',
  'Western Asia': 'mde', 'Central Asia': 'csa', 'Southern Asia': 'csa', 'Eastern Asia': 'ase', 'South-Eastern Asia': 'ase',
  'Northern Africa': 'afn', 'Western Africa': 'afw', 'Middle Africa': 'afc', 'Eastern Africa': 'afe', 'Southern Africa': 'afs',
  'Australia and New Zealand': 'oce', 'Melanesia': 'oce', 'Micronesia': 'oce', 'Polynesia': 'oce',
};
const SHEET_FIX = {
  MEX: 'nam', IRN: 'mde', POL: 'euw', CZE: 'euw', SVK: 'euw', HUN: 'euw', SVN: 'euw',
  ZMB: 'afs', ZWE: 'afs', MWI: 'afs', MOZ: 'afs', MDG: 'afs', SHN: 'afw', CYN: 'mde', ATA: '',
};
const SHEET_CONT = { sam: 'sa', nam: 'na', cam: 'na', car: 'na', eun: 'eu', euw: 'eu', eue: 'eu', eus: 'eu',
  mde: 'as', csa: 'as', ase: 'as', afn: 'af', afw: 'af', afc: 'af', afe: 'af', afs: 'af', oce: 'oc' };

// ---------- 1. merge the two sources ----------
const units = readJSON('ne_10m_admin_0_map_units.geojson');
const indView = readJSON('ne_10m_admin_0_countries_ind.geojson');
const props = {};
const features = [];
// Names come from the country-level file where it has the country, so that a country made of
// several map units (Belgium, Serbia, the UK) is not named after one of its parts.
const countryProps = Object.fromEntries(indView.features.map(f => [f.properties.ADM0_A3, f.properties]));
for (const f of units.features) {
  const p = f.properties;
  if (DROP.has(p.ADM0_A3) || FROM_INDIA_VIEW.has(p.ADM0_A3)) continue;
  const key = SPLIT_UNITS.has(p.GU_A3) ? p.GU_A3 : p.ADM0_A3;
  if (!props[key]) props[key] = SPLIT_UNITS.has(key) ? p : (countryProps[key] || p);
  features.push({ type: 'Feature', properties: { id: key }, geometry: f.geometry });
}
for (const f of indView.features) {
  const p = f.properties;
  if (!FROM_INDIA_VIEW.has(p.ADM0_A3)) continue;
  props[p.ADM0_A3] = p;
  features.push({ type: 'Feature', properties: { id: p.ADM0_A3 }, geometry: f.geometry });
}

// ---------- 2. drop specks of land before simplifying ----------
const ringAreaKm2 = ring => {
  let a = 0;
  for (let i = 0, n = ring.length - 1; i < n; i++) {
    const [x1, y1] = ring[i], [x2, y2] = ring[i + 1];
    a += (x2 - x1) * Math.PI / 180 * (2 + Math.sin(y1 * Math.PI / 180) + Math.sin(y2 * Math.PI / 180));
  }
  return Math.abs(a * 6371 * 6371 / 2);
};
const byId = {};
for (const f of features) (byId[f.properties.id] ||= []).push(f);
for (const list of Object.values(byId)) {
  const polys = list.flatMap(f => (f.geometry.type === 'Polygon' ? [f.geometry.coordinates] : f.geometry.coordinates)
    .map(c => ({ f, c, a: ringAreaKm2(c[0]) })));
  const ranked = [...polys].sort((a, b) => b.a - a.a);
  const keep = new Set(ranked.filter((p, i) => i < 4 || p.a >= 40).map(p => p.c));
  for (const f of list) {
    const cs = (f.geometry.type === 'Polygon' ? [f.geometry.coordinates] : f.geometry.coordinates).filter(c => keep.has(c));
    f.geometry = { type: 'MultiPolygon', coordinates: cs };
  }
}
const merged = { type: 'FeatureCollection', features: features.filter(f => f.geometry.coordinates.length) };

// ---------- 3. clean, dissolve and simplify with mapshaper ----------
console.log(`merging ${merged.features.length} map units ...`);
const out = await mapshaper.applyCommands(
  '-i in.json -clean -dissolve2 id -simplify interval=2200 keep-shapes -clean -o out.json format=topojson quantization=400000',
  { 'in.json': merged });
const topo = JSON.parse(out['out.json']);
const objName = Object.keys(topo.objects)[0];
const geoms = topo.objects[objName].geometries;
const neigh = topojson.neighbors(geoms);
const fc = topojson.feature(topo, topo.objects[objName]);

// ---------- 4. capitals ----------
const places = readJSON('ne_50m_populated_places.geojson').features.map(f => f.properties);
const capitals = {};
for (const p of places) {
  if (!/Admin-0 capital/.test(p.FEATURECLA || p.featurecla || '')) continue;
  const k = p.ADM0_A3, alt = /alt/.test(p.FEATURECLA || p.featurecla);
  if (!capitals[k] || (!alt && capitals[k].alt)) capitals[k] = { name: p.NAME, alt };
}

// ---------- 5. colours: no two neighbours alike, palette used evenly ----------
const PALETTE = 6;
const order = geoms.map((g, i) => i).sort((a, b) => neigh[b].length - neigh[a].length);
const colour = new Array(geoms.length).fill(-1);
const used = new Array(PALETTE).fill(0);
for (const i of order) {
  const taken = new Set(neigh[i].map(j => colour[j]));
  let best = -1;
  for (let c = 0; c < PALETTE; c++) if (!taken.has(c) && (best < 0 || used[c] < used[best])) best = c;
  if (best < 0) throw new Error('ran out of colours at ' + geoms[i].properties.id);
  colour[i] = best; used[best]++;
}

// ---------- 6. country records ----------
const Q = 1000; // coordinates stored in thousandths of a degree, delta encoded
const encodeRing = ring => {
  const outR = []; let px = 0, py = 0;
  for (let i = 0; i < ring.length - 1; i++) { // last point repeats the first
    const x = Math.round(ring[i][0] * Q), y = Math.round(ring[i][1] * Q);
    if (i && x === px && y === py) continue;
    outR.push(x - px, y - py); px = x; py = y;
  }
  return outR;
};
const records = [];
const problems = [];
fc.features.forEach((f, i) => {
  const id = f.properties.id;
  const p = props[id];
  const g = f.geometry;
  if (!g) { problems.push(`${id}: no shape`); return; }
  const polys = g.type === 'Polygon' ? [g.coordinates] : g.coordinates;
  // label point: pole of inaccessibility of the biggest polygon, on a locally scaled grid
  const big = polys.reduce((a, b) => (ringAreaKm2(b[0]) > ringAreaKm2(a[0]) ? b : a));
  const lat0 = big[0].reduce((s, c) => s + c[1], 0) / big[0].length;
  const kx = Math.cos(lat0 * Math.PI / 180);
  const pl = polylabel(big.map(r => r.map(([x, y]) => [x * kx, y])), 0.01);
  const anchor = [+(pl[0] / kx).toFixed(3), +pl[1].toFixed(3)];
  const area = Math.round(polys.reduce((s, c) => s + ringAreaKm2(c[0]) - c.slice(1).reduce((h, r) => h + ringAreaKm2(r), 0), 0));
  let lo = [180, 90], hi = [-180, -90];
  for (const c of polys) for (const [x, y] of c[0]) { lo = [Math.min(lo[0], x), Math.min(lo[1], y)]; hi = [Math.max(hi[0], x), Math.max(hi[1], y)]; }
  const status = UNLABELLED.has(id) ? 'o' : UN195.has(id) ? 'c' : 't';
  const sheet = id in SHEET_FIX ? SHEET_FIX[id] : (SUB_TO_SHEET[p.SUBREGION] || '');
  const iso2 = (p.ISO_A2_EH && p.ISO_A2_EH !== '-99' ? p.ISO_A2_EH : p.ISO_A2 !== '-99' ? p.ISO_A2 : '').toLowerCase();
  const name = SHORT[id] || p.NAME_EN || p.NAME;
  const cap = id in CAPITAL_FIX ? CAPITAL_FIX[id] : (capitals[id]?.name || '');
  if (status !== 'o') {
    if (!sheet) problems.push(`${id} ${name}: no sheet`);
    if (!cap && status === 'c') problems.push(`${id} ${name}: no capital`);
  }
  records.push({
    id, iso2, name,
    official: p.FORMAL_EN || p.NAME_LONG || name,
    capital: cap,
    status,
    sov: status === 't' && p.SOVEREIGNT && p.SOVEREIGNT !== p.ADMIN ? p.SOVEREIGNT : '',
    sheet,
    cont: id === 'ATA' ? 'an' : SHEET_CONT[sheet] || '',
    color: colour[i],
    anchor, area,
    bbox: [lo[0], lo[1], hi[0], hi[1]].map(v => +v.toFixed(2)),
    note: NOTES[id] || '',
    neighbours: neigh[i].map(j => geoms[j].properties.id),
    polys: polys.map(poly => poly.map(encodeRing)),
  });
});
records.sort((a, b) => a.name.localeCompare(b.name));

// ---------- 7. checks ----------
const ids = new Set(records.map(r => r.id));
for (const id of UN195) if (!ids.has(id)) problems.push(`${id}: UN country missing from the map`);
for (const r of records) for (const n of r.neighbours) {
  const o = records.find(x => x.id === n);
  if (o.color === r.color) problems.push(`${r.id}/${n}: neighbours share a colour`);
}
const js = '/* Generated by tools/build-map-data.mjs from Natural Earth (public domain). Do not edit by hand. */\n'
  + 'window.GEO_DATA = ' + JSON.stringify({ q: Q, built: new Date().toISOString().slice(0, 10), countries: records }) + ';\n';
fs.writeFileSync(OUT, js);
const counts = records.reduce((m, r) => (m[r.status]++, m), { c: 0, t: 0, o: 0 });
console.log(`world-shapes.js ${(js.length / 1e6).toFixed(2)} MB: ${counts.c} countries, ${counts.t} territories, ${counts.o} unlabelled areas; colours used ${used.join('/')}`);
if (problems.length) { console.log('PROBLEMS:\n  ' + problems.join('\n  ')); process.exitCode = 1; }
else console.log('All checks passed.');
