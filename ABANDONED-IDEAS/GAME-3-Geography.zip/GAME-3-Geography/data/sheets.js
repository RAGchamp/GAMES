/* Map sheet settings for WORLD-MAP.html (hand-written, edit freely).
 *
 *  id      unique name, also used in the page address (#sam)
 *  title   text in the yellow banner
 *  menu    text in the sheet menu
 *  group   menu group
 *  kind    'world'     Equal Earth projection, coloured by continent, continent names
 *          'continent' country colours, names written inside the big countries
 *          'region'    country colours, white flag labels with red arrows
 *  bbox    [west, south, east, north] in degrees, the area that must fit on the sheet
 *          (east may be more than 180 when a sheet crosses the date line)
 *  cont    continent code for 'continent' sheets: af as eu na sa oc
 *  anchors optional {CODE: [lon, lat]} to move where an arrow points on this sheet
 *  also    optional list of extra codes to label on a 'continent' sheet
 */
window.GEO_SHEETS = [
  { id: 'world', title: 'THE WORLD', menu: 'The whole world', group: 'World', kind: 'world' },

  { id: 'africa', title: 'AFRICA', menu: 'Africa (whole continent)', group: 'Africa', kind: 'continent', cont: 'af', bbox: [-19, -36, 53, 38] },
  { id: 'afn', title: 'NORTH AFRICA', menu: 'North Africa', group: 'Africa', kind: 'region', bbox: [-18, 13, 38, 37.5] },
  { id: 'afw', title: 'WEST AFRICA', menu: 'West Africa', group: 'Africa', kind: 'region', bbox: [-25.5, 3.5, 16.5, 27.5] },
  { id: 'afc', title: 'CENTRAL AFRICA', menu: 'Central Africa', group: 'Africa', kind: 'region', bbox: [5.5, -18.5, 31.5, 23.5] },
  { id: 'afe', title: 'EAST AFRICA', menu: 'East Africa', group: 'Africa', kind: 'region', bbox: [23, -21.5, 58, 18.5] },
  { id: 'afs', title: 'SOUTHERN AFRICA', menu: 'Southern Africa', group: 'Africa', kind: 'region', bbox: [11, -35.5, 51, -8] },

  { id: 'asia', title: 'ASIA', menu: 'Asia (whole continent)', group: 'Asia', kind: 'continent', cont: 'as', bbox: [26, -10, 148, 77], also: ['RUS'], anchors: { RUS: [95, 63] } },
  { id: 'mde', title: 'MIDDLE EAST', menu: 'Middle East and Caucasus', group: 'Asia', kind: 'region', bbox: [25, 12, 63, 43.5] },
  { id: 'csa', title: 'CENTRAL & SOUTH ASIA', menu: 'Central and South Asia', group: 'Asia', kind: 'region', bbox: [46, -1, 97, 55.5] },
  { id: 'ase', title: 'EAST & SOUTHEAST ASIA', menu: 'East and Southeast Asia', group: 'Asia', kind: 'region', bbox: [92, -11, 146, 53.5] },

  { id: 'europe', title: 'EUROPE', menu: 'Europe (whole continent)', group: 'Europe', kind: 'continent', cont: 'eu', bbox: [-24, 34, 46, 71], anchors: { RUS: [42, 57] } },
  { id: 'eun', title: 'NORTHERN EUROPE', menu: 'Northern Europe and British Isles', group: 'Europe', kind: 'region', bbox: [-24, 50, 31, 71] },
  { id: 'euw', title: 'WESTERN & CENTRAL EUROPE', menu: 'Western and Central Europe', group: 'Europe', kind: 'region', bbox: [-5, 42.3, 24, 55] },
  { id: 'eue', title: 'EASTERN EUROPE', menu: 'Eastern Europe', group: 'Europe', kind: 'region', bbox: [20, 41, 48, 60], anchors: { RUS: [40.5, 55.5] } },
  { id: 'eus', title: 'SOUTHERN EUROPE', menu: 'Southern Europe and the Balkans', group: 'Europe', kind: 'region', bbox: [-10, 35, 29, 47], anchors: { SRB: [20.6, 44.7] } },

  { id: 'namerica', title: 'NORTH AMERICA', menu: 'North America (whole continent)', group: 'North America', kind: 'continent', cont: 'na', bbox: [-168, 7, -15, 80] },
  { id: 'nam', title: 'USA, CANADA & MEXICO', menu: 'USA, Canada, Mexico, Greenland', group: 'North America', kind: 'region', bbox: [-168, 14, -15, 80] },
  { id: 'cam', title: 'CENTRAL AMERICA', menu: 'Central America', group: 'North America', kind: 'region', bbox: [-92.5, 7, -77, 18.5] },
  { id: 'car', title: 'CARIBBEAN', menu: 'Caribbean', group: 'North America', kind: 'region', bbox: [-85, 10, -59.5, 27] },

  { id: 'sam', title: 'SOUTH AMERICA', menu: 'South America', group: 'South America', kind: 'region', bbox: [-82, -56, -34, 13] },

  { id: 'oce', title: 'OCEANIA', menu: 'Australia and the Pacific', group: 'Oceania', kind: 'region', bbox: [112, -48, 212, 15] },
];
